<?php
$fn=$_POST["fname"];
$mn=$_POST["mname"];
$ln=$_POST["lname"];
$a=$_POST["dob"];
$dept=$_POST["dept"];
$id=$_POST["id"];
$lname=$_POST["lname"];
$des=$_POSt["des"];
$amt=$_POST["amt"];
$gen=$_POST["gen"];
$dop=$_POST["dop"];
$ct=$_POST["ct"];
$em=$_POST["em"];
$addr=$_POST["addr"];
$additional=$_POST["additional"];
echo "fname: ".$fn;
echo "<br>";
echo "mname: ".$mn;
echo "<br>";
echo "lname: ".$ln;
echo "<br>";
echo "Gender: ".$gen;
echo "<br>";
echo "Contact: ".$num;
echo "<br>";
echo "Email: ".$em;
echo "<br>";
echo "Address: ".$addr;
echo "<br>";
echo "City: ".$ct;
echo "<br>";
echo "Department: ".$dept;
echo "<br>";
echo " ID: ".$id;
echo "<br>";

$fname="";
foreach ($skl as $i){
echo $i."<br />";
$fname=$fname.",".$i;
}
echo "lname:".$lname;
echo "<br>";
echo "Additional skill: ".$additional;
echo "<br>";

/*
echo "dmem: ".$_GET["dmem"];
echo "<br>";
echo "imem: ".$_GET["imem"];
echo "<br>";
*/
echo "amt: ".$amt;
echo "<br>";


include "connect.php";

$sql = "INSERT INTO membership VALUES('$fn','$mn','$ln','$a','$dept','$id','$lname','$des','$amt','$gen','$dop','$ct','$em','$addr','$additional',)";
      
		$result = mysqli_query($con,$sql);


?>


