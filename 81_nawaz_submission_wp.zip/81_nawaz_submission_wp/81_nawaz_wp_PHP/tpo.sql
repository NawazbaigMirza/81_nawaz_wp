-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 10, 2017 at 11:08 AM
-- Server version: 5.5.54-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tpo`
--

-- --------------------------------------------------------

--
-- Table structure for table `tpo`
--

CREATE TABLE IF NOT EXISTS `tpo` (
  `fn` varchar(10) NOT NULL,
  `mn` varchar(10) NOT NULL,
  `ln` varchar(10) NOT NULL,
  `a` int(1) NOT NULL,
  `dept` varchar(1) NOT NULL,
  `id` varchar(10) NOT NULL,
  `lname` varchar(10) NOT NULL,
  `des` varchar(10) NOT NULL,
  `amt` int(1) NOT NULL,
  `gen` int(1) NOT NULL,
  `dop` date NOT NULL,
  `ct` varchar(10) NOT NULL,
  `em` text NOT NULL,
  `addr` varchar(10) NOT NULL,
  `additional` varchar(10) NOT NULL,
  `aa` int(1) NOT NULL,
  `b` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
