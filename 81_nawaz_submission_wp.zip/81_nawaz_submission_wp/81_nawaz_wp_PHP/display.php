<?php

include "connect.php";
$sql = "select * from tpo";

$result = $con->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
	$i=0;
    while($row = $result->fetch_assoc()) {
        echo "id: ".$sid ." First name=". $row["fn"]. " Middle Name=:". $row["mn"]. " Last Name " . $row["ln"]. "add". $row["a"]."sid".$row["id"]."department".$row["dept"]"industry name".$row["lname"].$row["des"].$row["amt"].$row["gen"].$row.["dop"].$row["ct"].$row["em"].$row["addr"].$row["additional"]<br>";
		$i++;
    }
} else {
    echo "0 results";
}
$con->close();

?>
echo "id: ".$i." First name=". $row["fn"]. " Middle Name: " . $row["mn"]. " Last Name " . $row["ln"]. "<br>";
