<script src="../lib/jquery.js"></script>
	<script src="../dist/jquery.validate.js"></script>
<script>
$.validator.setDefaults({
		submitHandler: function() {
			alert("submitted!");
		}
	});

$().ready(function() {
  
  
   	$("#form").validate({
			rules: {
			pic:"required",
			fname:"required",
			mname:"required",
			lname:"required",
			'gender':{required :true},
			dob :"required",
			phoneno :{
			required :true,
			digits : true
			},
			email:{
			required:true,
			email:true,
			},
			},
			messages:{
			pic :" Upload Profile photo",
			fname: "Firstname  Cannot be blank",
			mname : "MiddleName Cannot be Blank",
			lname : "LastName Cannot be Blank",
			gender :"Please Select gender",
			dob :"DOB cannot be Empty",
			phoneno:{
			required :"Phoneno Cannot be Empty",
			digits :"Please Enter Only digits"
			},
			email:{
			required:"Email Cannot be Empty",
			email:"Enter Valid email address",
			},
			}
			});
});
</script>